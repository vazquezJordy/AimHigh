//
//  DetailOfGoalsViewController.swift
//  AimHigh
//
//  Created by Jordy Vazquez on 6/14/20.
//  Copyright © 2020 Jordy Vazquez. All rights reserved.
//

import UIKit

class DetailOfGoalsViewController: UIViewController {
    
    var goal: GoalStructure?
    
    @IBOutlet weak var reasonOfGoalOutPut1: UILabel!
    @IBOutlet weak var reasonOfGoalOutPut2: UILabel!
    @IBOutlet weak var reasonOfGoalOutPut3: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = goal?.nameOfGoal
        
        guard let goal = goal else {return}

        if goal.reasonsForGoal.count > 0 {
            reasonOfGoalOutPut1.text = goal.reasonsForGoal[0]
        }

        if goal.reasonsForGoal.count > 1 {


            reasonOfGoalOutPut2.text = goal.reasonsForGoal[1]

        }
        if goal.reasonsForGoal.count > 2 {

            reasonOfGoalOutPut3.text = goal.reasonsForGoal[2]

        }
    }
    
    @IBAction func detailViewControllerUnwind(_ seg: UIStoryboardSegue) {
          
      }
    
}
    

